import * as React from "react";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import CommuteIcon from "@mui/icons-material/Commute";

export const mainListItems = (
  <div>
    <ListItem button>
      <ListItemIcon>
        <CommuteIcon />
      </ListItemIcon>
      <ListItemText primary="Trip Planner" />
    </ListItem>
  </div>
);
