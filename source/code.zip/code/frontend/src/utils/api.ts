import axios from "axios";
import * as dotenv from "dotenv";

dotenv.config();

export const axiosInstance = axios.create({
  // baseURL: process.env.APP_BACKEND_URL,
  baseURL: "http://65.1.90.184:7001/v1/bap_mobility",
  headers: {
    "Content-type": "application/json",
  },
});
