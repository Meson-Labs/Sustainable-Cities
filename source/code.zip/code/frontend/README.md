# Installation and usage
- To run in development mode
    ```bash
    npm install
    npm start
    ```

- To run in production
    ```docker-compose up -d
    ```
