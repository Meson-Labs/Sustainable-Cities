import orjson

from schema.context import Context
from schema.message import MessageForSearch, MessageForOn_search
from utils.wrappers import get_all_nodes
from utils.aio_http import AiohttpClient


async def call_bpp_search(
    context: Context,
    message: MessageForSearch,
    bpp_id: str = None,
    bpp_uri: str = None,
):
    search_body = {
        "context": context.dict(),
        "message": message.dict(),
    }

    if bpp_id is not None:
        search_body["context"]["bpp_id"] = bpp_id
    if bpp_uri is not None:
        search_body["context"]["bpp_uri"] = bpp_uri

    response = await AiohttpClient.post_request(
        url=f"{bpp_uri}/search",
        data=orjson.dumps(search_body),
    )

    return response


async def handle_search(
    context: Context,
    message: MessageForSearch,
):
    async for node in get_all_nodes():
        if "bpp" in node["id"]:
            await call_bpp_search(context, message, node["id"], node["uri"])


async def handle_on_search(
    context: Context,
    message: MessageForOn_search,
):
    response_body = {
        "context": context.dict(),
        "message": message.dict(),
    }
    bap_uri = context.dict()["bap_uri"]

    response = await AiohttpClient.post_request(
        url=f"{bap_uri}/on_search",
        data=orjson.dumps(response_body),
    )

    return response
