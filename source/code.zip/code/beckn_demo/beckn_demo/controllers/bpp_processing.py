import orjson


from schema.context import Context
from schema.message import MessageForSelect
from utils.wrappers import get_primary_bg
from utils.aio_http import AiohttpClient


async def handle_search(context: Context):
    response_catalog = {
        "bpp_descriptor": {
            "name": "bpp_processor",
            "long_desc": "BPP for primary processing",
        },
        "bpp_categories": [
            {
                "id": "mobility",
                "descriptor": {
                    "name": "mobility",
                },
            },
        ],
    }
    response_body = {}
    response_body["context"] = context.dict()
    response_body["message"] = {
        "catalog": response_catalog,
    }

    bg_node = await get_primary_bg()
    bg_uri = bg_node["uri"]

    response = await AiohttpClient.post_request(
        url=f"{bg_uri}/on_search",
        data=orjson.dumps(response_body),
    )

    return response


async def handle_select(context: Context, message: MessageForSelect):
    print(message.dict())
    return None
