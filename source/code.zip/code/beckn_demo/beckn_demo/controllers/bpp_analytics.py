import orjson


from schema.core import Fulfillment, Order
from schema.context import Context
from schema.message import (
    MessageForSearch,
    MessageForConfirm,
    MessageForOn_search,
    MessageForOn_confirm,
)

from utils.core import convert_str_to_coords
from utils.wrappers import get_primary_bg
from utils.aio_http import AiohttpClient
from controllers.geo import get_poi_routes, convert_coords_to_poi_name


async def get_service_catalog():
    service_catalog = {
        "bpp_descriptor": {
            "name": "bpp_analytics",
            "long_desc": "BPP for location analytics",
        },
        "bpp_categories": [
            {
                "id": "mobility",
                "descriptor": {
                    "name": "mobility",
                },
            },
        ],
        "bpp_offers": [
            {
                "id": "route_planning",
                "descriptor": {
                    "name": "Route planning",
                },
                "category_ids": ["mobility"],
                "item_ids": [
                    "plan_by_orig_dest",
                ],
            },
        ],
    }
    return service_catalog


async def get_orig_dest_search_catalog():
    bpp_providers = [
        {
            "id": "bpp_processing",
            "descriptor": {
                "name": "bpp_processor",
                "long_desc": "BPP for primary processing",
            },
            "categories": [
                {
                    "id": "mobility",
                    "descriptor": {
                        "name": "mobility",
                    },
                },
            ],
            "items": [
                {
                    "id": "metro",
                    "descriptor": {
                        "name": "Metro network",
                    },
                    "category_id": "spot_booking",
                    "location_id": "closest-metro-station",
                    "price": {
                        "currency": "INR",
                        "value": "50",
                    },
                    "matched": True,
                },
            ],
        },
    ]
    result_catalog = {
        "bpp_descriptor": {
            "name": "bpp_analytics",
            "long_desc": "BPP for location analytics",
        },
        "bpp_categories": [
            {
                "id": "mobility",
                "descriptor": {
                    "name": "mobility",
                },
            },
        ],
        "bpp_providers": bpp_providers,
    }
    return result_catalog


async def create_routes_response(route_details):
    fulfillment = Fulfillment(
        tags={
            "route_details": route_details,
        }
    )
    result = Order(fulfillment=fulfillment)
    return result


async def handle_search(context: Context, message: MessageForSearch):
    message_body = message.dict()
    # if "intent" in message_body and message_body["intent"]["fulfillment"] is None:
    service_catalog = await get_service_catalog()

    response_body = {}
    response_body["context"] = context.dict()
    response_body["message"] = {
        "catalog": service_catalog,
    }

    bg_node = await get_primary_bg()
    bg_uri = bg_node["uri"]

    response = await AiohttpClient.post_request(
        url=f"{bg_uri}/on_search",
        data=orjson.dumps(response_body),
    )

    return response


async def handle_confirm(context: Context, message: MessageForConfirm):
    message_body = message.dict()

    orig_coords = message_body["order"]["fulfillment"]["start"]["location"]["gps"]
    dest_coords = message_body["order"]["fulfillment"]["end"]["location"]["gps"]

    start_poi_name, end_poi_name = convert_coords_to_poi_name(
        convert_str_to_coords(orig_coords),
        convert_str_to_coords(dest_coords),
    )

    response_message = MessageForOn_confirm(
        order=await create_routes_response(
            route_details=get_poi_routes(start_poi_name, end_poi_name)
        ),
    )
    response_body = {
        "context": context.dict(),
        "message": response_message.dict(),
    }

    # Send response directly to BAP
    bap_uri = context.dict()["bap_uri"]

    response = await AiohttpClient.post_request(
        url=f"{bap_uri}/on_confirm",
        data=orjson.dumps(response_body),
    )

    return response
