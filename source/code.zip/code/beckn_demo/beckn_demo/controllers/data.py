import pandas as pd

from pathlib import Path

from utils.cache import DataCache


DATA_HOME = "/code/data/"  # pylint: disable=undefined-variable


def get_all_datasets():
    ## Store relative paths of datasets of interest
    datasets = {
        "auto_stands": "Auto Stands Locations/Auto_Stands.csv",
        "bus_stops": "Bus/CSV/BusStops.csv",
        "bus_routes": "Bus/CSV/BusRoutes.csv",
        "bus_gtfs_routes": "Bus/GTFS/routes.txt",
        "ferry_routes": "Ferry/Ferry - CSV/Routes.csv",
        "ferry_schedules": "Ferry/Ferry - CSV/Schedules.csv",
        "ferry_stops": "Ferry/Ferry - CSV/Stop_Locations.csv",
        "ferry_trips": "Ferry/Ferry - CSV/Trips.csv",
        "metro_routes": "Kochi Metro/KMRL - CSV/Routes.csv",
        "metro_fares": "Kochi Metro/KMRL - CSV/Fares.csv",
        "metro_schedules": "Kochi Metro/KMRL - CSV/Schedules.csv",
        "metro_stops": "Kochi Metro/KMRL - CSV/Stops.csv",
        "metro_trips": "Kochi Metro/KMRL - CSV/Trips.csv",
        "poi_accommodation": "locations/Accommodation.csv",
        "poi_cultural": "locations/Cultural.csv",
        "poi_educational_establishments": "locations/Educational_Establishments.csv",
        "poi_gastronomy": "locations/Gastronomy.csv",
        "poi_medical_establishments": "locations/Medical_Establishments.csv",
        "poi_other_amenities": "locations/Other_Amenities.csv",
        "poi_recreation": "locations/Recreation.csv",
        "poi_religious_establishments": "locations/Religious_Establishments.csv",
        # "all_poi": "locations/Recreational_Establishments.csv",
    }
    return datasets


def read_data(dataset_name: str):
    datasets = get_all_datasets()

    # Try reading from cache first and go do disc only if not saved in cache
    data = DataCache.read(dataset_name)

    if data is None:
        rel_path = datasets.get(dataset_name)
        file_url = Path(DATA_HOME, rel_path)

        if file_url.suffix in [".csv", ".txt"]:
            data = pd.read_csv(
                file_url,
                encoding="unicode_escape",
            )
            # Remove trailing spaces from column names
            data.columns = [col.strip() for col in data.columns]
            DataCache.write(dataset_name, data)

    return data


def aggregate_poi():
    datasets = get_all_datasets()

    all_poi = []
    for key in datasets:
        if key.startswith("poi"):
            poi_data = read_data(key)
            poi_data.columns = ["Name", "Category", "Latitude", "Longitude"]
            all_poi.append(poi_data)
    result = pd.concat(all_poi)
    result["Category"] = result["Category"].str.title()
    result = result.sort_values(by=["Category", "Name"]).drop_duplicates(subset="Name")

    return result


# Generate json for use in frontend
# json.dumps(aggregate_poi()[["Name", "Category"]].to_dict(orient='records'))
