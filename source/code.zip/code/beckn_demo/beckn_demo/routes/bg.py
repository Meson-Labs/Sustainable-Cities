import logging

from fastapi import APIRouter
from fastapi.responses import ORJSONResponse

from schema.core import Error
from schema.context import Context
from schema.message import MessageForSearch, MessageForOn_search
from utils.wrappers import create_ack_response, create_nack_response
from controllers.bg import handle_search, handle_on_search


router = APIRouter(default_response_class=ORJSONResponse)
logger = logging.getLogger(__name__)


@router.post("/search")
async def search(
    context: Context,
    message: MessageForSearch,
):
    try:
        await handle_search(context, message)

        ack_response = await create_ack_response(context=context)
        return ack_response
    except Exception as e:
        logger.error(e)
        nack_response = await create_nack_response(context=context)
        return nack_response


@router.post("/on_search")
async def on_search(
    context: Context, message: MessageForOn_search = None, error: Error = None
):
    try:
        await handle_on_search(context, message)

        ack_response = await create_ack_response(context=context)
        return ack_response
    except Exception as e:
        logger.error(e)
        nack_response = await create_nack_response(context=context)
        return nack_response
