from typing import Any


class DataCache:
    all_data = {}

    @classmethod
    def reset(cls):
        cls.all_data = {}

    @classmethod
    def read(cls, dataset_name: str):
        if dataset_name in cls.all_data and cls.all_data[dataset_name] is not None:
            result = cls.all_data[dataset_name]
        else:
            result = None

        return result

    @classmethod
    def write(cls, dataset_name: str, data: Any):
        cls.all_data[dataset_name] = data
