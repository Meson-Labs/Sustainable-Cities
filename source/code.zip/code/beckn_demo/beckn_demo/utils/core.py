def convert_coords_to_str(coords):
    return str(coords[0]) + ", " + str(coords[1])


def convert_str_to_coords(s):
    return tuple(float(x) for x in s.split(", "))
