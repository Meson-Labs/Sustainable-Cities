from pydantic import BaseModel
from typing import Dict, List, Optional

from schema.enums import AckResponse, PaymentTypes


class Ack(BaseModel):
    status: AckResponse


class Error(BaseModel):
    error_type: str
    code: str
    path: str
    message: str


class Scalar(BaseModel):
    scalar_type: str = None
    value: float = None
    estimated_value: float = None
    computed_value: float = None
    range_min: float = None
    range_max: float = None
    unit: str = None


class City(BaseModel):
    name: str
    code: str


class Country(BaseModel):
    name: str
    code: str


class Circle(BaseModel):
    gps: str
    radius: Scalar


class Image(BaseModel):
    url: str = None


class Duration(BaseModel):
    duration: str = None


class Time(BaseModel):
    label: str = None
    timestamp: str = None
    duration: str = None
    days: str = None


class Descriptor(BaseModel):
    name: Optional[str] = None
    code: str = None
    symbol: str = None
    short_desc: str = None
    long_desc: str = None
    images: List[Image] = None
    audio: str = None
    three_d_render: str = None


class Category(BaseModel):
    id: str = None
    parent_id: str = None
    descriptor: Descriptor = None
    time: Time = None
    tags: Dict = None


class Person(BaseModel):
    name: str
    image: Image
    dob: str
    gender: str
    cred: str
    tags: Dict


class State(BaseModel):
    descriptor: Descriptor
    updated_at: str
    updated_by: str


class Address(BaseModel):
    door: str
    name: str
    building: str
    street: str
    locality: str
    ward: str
    city: str
    state: str
    country: str
    area_code: str


class Vehicle(BaseModel):
    category: str
    capacity: int
    make: str
    model: str
    size: str
    variant: str
    color: str
    energy_type: str
    registration: str


class Location(BaseModel):
    id: str = None
    descriptor: Descriptor = None
    gps: str = None
    address: Address = None
    station_code: str = None
    city: City = None
    country: Country = None
    circle: Circle = None
    polygon: str = None
    three_d_space: str = None
    time: Time = None


class Contact(BaseModel):
    phone: str
    email: str
    tags: Dict


class Payment(BaseModel):
    uri: str
    tl_method: str
    params: Dict
    payment_type: PaymentTypes
    status: str
    time: Time


class Price(BaseModel):
    currency: str = None
    value: float = None
    estimated_value: float = None
    computed_value: float = None
    listed_value: float = None
    offered_value: float = None
    minimum_value: float = None
    maximum_value: float = None


class Agent(BaseModel):
    name: str = None
    image: Image = None
    dob: str = None
    gender: str = None
    cred: str = None
    phone: str = None
    email: str = None
    tags: Dict = None


class Offer(BaseModel):
    id: str = None
    descriptor: Descriptor = None
    location_ids: List[str] = None
    category_ids: List[str] = None
    item_ids: List[str] = None
    time: Time = None


class Item(BaseModel):
    id: str = None
    parent_item_id: str = None
    descriptor: Descriptor = None
    price: Price = None
    category_id: str = None
    location_id: str = None
    time: Time = None
    matched: bool = None
    related: bool = None
    recommended: bool = None
    tags: Dict = None


class ScalarQuantity(BaseModel):
    count: int
    measure: Scalar


class ItemQuantity(BaseModel):
    allocated: ScalarQuantity = None
    available: ScalarQuantity = None
    maximum: ScalarQuantity = None
    minimum: ScalarQuantity = None
    selected: ScalarQuantity = None


class StartOrEnd(BaseModel):
    location: Location = None
    time: Time = None
    instructions: Descriptor = None
    contact: Contact = None
    person: Person = None


class Fulfillment(BaseModel):
    id: str = None
    fulfillment_type: str = None
    provider_id: int = None
    state: State = None
    tracking: bool = None
    customer: str = None
    agent: Agent = None
    vehicle: Vehicle = None
    start: StartOrEnd = None
    end: StartOrEnd = None
    # start.location: Location
    # start.time: Time
    # start.instructions: Descriptor
    # start.contact: Contact
    # start.person: Person
    # end.location: Location
    # end.time: Time
    # end.instructions: Descriptor
    # end.contact: Contact
    # end.person: Person
    tags: Dict = None


class Provider(BaseModel):
    id: str = None
    descriptor: Descriptor = None
    category_id: str = None
    time: Time = None
    categories: List[Category] = None
    fulfillments: List[Fulfillment] = None
    payments: List[Payment] = None
    locations: List[Location] = None
    offers: List[Offer] = None
    items: List[Item] = None
    exp: str = None
    tags: Dict = None


class Intent(BaseModel):
    provider: Optional[Provider] = None
    # provider.id: str
    # provider.descriptor: Descriptor
    # provider.category_id: str
    # provider.locations: [str]
    fulfillment: Optional[Fulfillment] = None
    # fulfillment.id: str
    # fulfillment.start.location: Location
    # fulfillment.start.time: Time
    # fulfillment.end.location: Location
    # fulfillment.end.time: Time
    # fulfillment.tags: Dict
    # fulfillment.vehicle: Vehicle
    payment: Optional[Payment] = None
    category: Optional[Category] = None
    offer: Optional[Offer] = None
    item: Optional[Item] = None
    tags: Optional[str] = None


class Catalog(BaseModel):
    bpp_descriptor: Optional[Descriptor] = None
    bpp_categories: List[Category] = None
    bpp_fulfillments: List[Fulfillment] = None
    bpp_payments: List[Payment] = None
    bpp_offers: List[Offer] = None
    bpp_providers: List[Provider] = None
    exp: Optional[str]


class AddOn(BaseModel):
    id: str = None
    descriptor: Descriptor = None
    price: Price = None


class Organization(BaseModel):
    name: str = None
    cred: str = None


class Billing(BaseModel):
    name: str = None
    organization: Organization = None
    address: Address = None
    email: str
    phone: str
    time: Time
    tax_number: str
    created_at: str
    updated_at: str


class Quotation(BaseModel):
    price: Price = None
    breakup: str = None
    ttl: Duration = None


class Order(BaseModel):
    id: str = None
    state: str = None
    items: List[Item] = None
    add_ons: List[AddOn] = None
    offers: List[Offer] = None
    billing: Billing = None
    fulfillment: Fulfillment = None
    quote: Quotation = None
    payment: Payment = None
    created_at: str = None
    updated_at: str = None
