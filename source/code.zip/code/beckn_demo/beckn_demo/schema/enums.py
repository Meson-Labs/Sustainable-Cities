from enum import Enum, EnumMeta


class EnumBase:
    """
    Base class for all Enums. Override equals function so == checks by value and not by object id
    """

    @classmethod
    def _missing_(cls: EnumMeta, key):
        return next(
            (m for m in cls.__members__.values() if m.value.lower() == key.lower()),
            None,
        )  # pylint: disable=no-member

    def __repr__(self):
        return self.value  # pylint: disable=no-member

    def __eq__(self, other):
        if self.__class__.__name__ == other.__class__.__name__:
            return self.value == other.value  # pylint: disable=no-member
        return False

    def __contains__(self, member):
        return member._name_ in self._member_map_  # pylint: disable=no-member

    @classmethod
    def values(cls: EnumMeta):
        return set(item.value for item in cls)


class SystemState(EnumBase, Enum):
    Development = "Development"
    QA = "QA"
    Staging = "Staging"
    Production = "Production"


class AckResponse(EnumBase, Enum):
    ACK = "ACK"
    NACK = "NACK"


class ErrorTypes(EnumBase, Enum):
    CONTEXT_ERROR = "CONTEXT-ERROR"
    CORE_ERROR = "CORE-ERROR"
    DOMAIN_ERROR = "DOMAIN-ERROR"
    POLICY_ERROR = "POLICY-ERROR"
    JSON_SCHEMA_ERROR = "JSON-SCHEMA-ERROR"


class ScalarTypes(EnumBase, Enum):
    CONSTANT = "CONSTANT"
    VARIABLE = "VARIABLE"


class PaymentTypes(EnumBase, Enum):
    ON_ORDER = "ON-ORDER"
    PRE_FULFILLMENT = "PRE-FULFILLMENT"
    ON_FULFILLMENT = "ON-FULFILLMENT"
    POST_FULFILLMENT = "POST-FULFILLMENT"


class PaymentStatus(EnumBase, Enum):
    PAID = "PAID"
    NOT_PAID = "NOT-PAID"


class PaymentMethod(EnumBase, Enum):
    HTTP_GET = "http/get"
    HTTP_POST = "http/post"
