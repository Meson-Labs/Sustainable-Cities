def test_base():
    assert True
