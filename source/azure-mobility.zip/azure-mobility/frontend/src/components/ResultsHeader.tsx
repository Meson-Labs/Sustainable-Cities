import * as React from "react";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";

export default function ResultsHeader() {
  return (
    <React.Fragment>
      <TableHead>
        <TableRow>
          <TableCell>
            <TableRow>
              <TableCell style={{ borderBottom: "none", fontWeight: "bold" }}>
                Mode
              </TableCell>
            </TableRow>
          </TableCell>

          <TableCell>
            <TableRow>
              <TableCell style={{ borderBottom: "none", fontWeight: "bold" }}>
                Start
              </TableCell>
            </TableRow>
          </TableCell>

          <TableCell>
            <TableRow>
              <TableCell style={{ borderBottom: "none", fontWeight: "bold" }}>
                End
              </TableCell>
            </TableRow>
          </TableCell>

          <TableCell>
            <TableRow>
              <TableCell style={{ borderBottom: "none", fontWeight: "bold" }}>
                Price
              </TableCell>
            </TableRow>
          </TableCell>

          <TableCell>
            <TableRow>
              <TableCell style={{ borderBottom: "none", fontWeight: "bold" }}>
                Action
              </TableCell>
            </TableRow>
          </TableCell>
        </TableRow>
      </TableHead>
    </React.Fragment>
  );
}
