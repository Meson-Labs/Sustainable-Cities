import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";

import poiOptions from "../json/allPoi.json";

import Title from "./Title";

interface PoiData {
  Name: string;
  Category: string;
}

const PoiForm = (props: CompProps) => {
  const [origName, setOrigName] = useState<PoiData | undefined | null>(null);
  const [destName, setDestName] = useState<PoiData | undefined | null>(null);

  const handleSubmit = (e: any) => {
    alert("you have searched for - " + origName?.Name + " " + destName?.Name);
    // or you can send to backend
  };

  return (
    <React.Fragment>
      <Title>Points of Interest</Title>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8} lg={9}>
          <Autocomplete
            disablePortal
            id="origin-combo-box"
            options={poiOptions}
            groupBy={(option) => option.Category}
            getOptionLabel={(option) => option.Name}
            sx={{ width: 400 }}
            renderInput={(params) => <TextField {...params} label="Origin" />}
            value={origName}
            onChange={(_event, newValue) => {
              setOrigName(newValue);
            }}
          />
        </Grid>

        <Grid item xs={12} md={8} lg={9}>
          <Autocomplete
            disablePortal
            id="dest-combo-box"
            options={poiOptions}
            groupBy={(option) => option.Category}
            getOptionLabel={(option) => option.Name}
            sx={{ width: 400 }}
            renderInput={(params) => (
              <TextField {...params} label="Destination" />
            )}
            value={destName}
            onChange={(_event, newValue) => {
              setDestName(newValue);
            }}
          />
        </Grid>

        <Grid item xs={12} md={8} lg={9}>
          <Button variant="outlined" onClick={handleSubmit}>
            Search
          </Button>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

interface CompProps {}

export { PoiForm };
