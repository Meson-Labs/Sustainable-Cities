import React, { useState } from "react";

import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";

import Toolbar from "@mui/material/Toolbar";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
import Link from "@mui/material/Link";

import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";

import poiOptions from "../json/allPoi.json";
import Copyright from "./copyright";
import Title from "./Title";

import { axiosInstance } from "../utils/api";
import { useInterval } from "../utils/interval";
import ResultsHeader from "./ResultsHeader";

interface PoiData {
  Name: string;
  Category: string;
}

interface RouteDetailRow {
  Mode: string[];
  Start: string[];
  End: string[];
  Price: number | null;
}
interface RouteDetails extends Array<RouteDetailRow> {}

const TripPlanner = (props: CompProps) => {
  const delay = 1000;
  const [origName, setOrigName] = useState<PoiData | undefined | null>(null);
  const [destName, setDestName] = useState<PoiData | undefined | null>(null);
  const [isDisplayed, setDisplayed] = useState<boolean>(false);

  const [routeDetails, setRouteDetails] = useState<
    RouteDetails | undefined | null
  >(null);

  const routeIndexes = [0, 1, 2];

  const handleSubmit = (e: any) => {
    setRouteDetails(null);
    axiosInstance
      .post("/search_by_origin_dest", {
        orig_name: origName?.Name,
        dest_name: destName?.Name,
      })
      .then((response) => {
        // console.log(response.data);
        setDisplayed(false);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  useInterval(
    async () => {
      await axiosInstance
        .post("/get_route_details")
        .then((response) => {
          if (response.data) {
            setRouteDetails(response.data);
            // console.log(response.data);
            setDisplayed(true);
          }
        })
        .catch((e) => {
          console.log(e);
        });
    },
    isDisplayed ? null : delay
  );

  return (
    <React.Fragment>
      <Toolbar />
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Grid container spacing={3}>
          {/* Form for entering origin and destination */}
          <Grid item xs={12} md={8} lg={9}>
            <Paper
              sx={{
                p: 2,
                display: "flex",
                flexDirection: "column",
                height: 300,
              }}
            >
              <Title>Points of Interest</Title>

              <Grid container spacing={3}>
                <Grid item xs={12} md={8} lg={9}>
                  <Autocomplete
                    disablePortal
                    id="origin-combo-box"
                    options={poiOptions}
                    groupBy={(option) => option.Category}
                    getOptionLabel={(option) => option.Name}
                    sx={{ width: 400 }}
                    renderInput={(params) => (
                      <TextField {...params} label="Origin" />
                    )}
                    value={origName}
                    onChange={(_event, newValue) => {
                      setOrigName(newValue);
                    }}
                  />
                </Grid>

                <Grid item xs={12} md={8} lg={9}>
                  <Autocomplete
                    disablePortal
                    id="dest-combo-box"
                    options={poiOptions}
                    groupBy={(option) => option.Category}
                    getOptionLabel={(option) => option.Name}
                    sx={{ width: 400 }}
                    renderInput={(params) => (
                      <TextField {...params} label="Destination" />
                    )}
                    value={destName}
                    onChange={(_event, newValue) => {
                      setDestName(newValue);
                    }}
                  />
                </Grid>

                <Grid item xs={12} md={8} lg={9}>
                  <Button variant="outlined" onClick={handleSubmit}>
                    Search
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </Grid>

          {/* Section for displaying results */}
          <Grid item xs={12}>
            <Paper sx={{ p: 2, display: "flex", flexDirection: "column" }}>
              <Title>Results</Title>
              {routeDetails ? (
                <Table size="small">
                  <ResultsHeader />

                  <TableBody>
                    {routeIndexes.map((idx) => (
                      <TableRow>
                        <TableCell>
                          {routeDetails[idx] &&
                            routeDetails[idx].Mode &&
                            routeDetails[idx].Mode.map((row) => (
                              <TableRow>
                                <TableCell style={{ borderBottom: "none" }}>
                                  {row}
                                </TableCell>
                              </TableRow>
                            ))}
                        </TableCell>

                        <TableCell>
                          {routeDetails[idx] &&
                            routeDetails[idx].Start &&
                            routeDetails[idx].Start.map((row) => (
                              <TableRow>
                                <TableCell style={{ borderBottom: "none" }}>
                                  {row}
                                </TableCell>
                              </TableRow>
                            ))}
                        </TableCell>

                        <TableCell>
                          {routeDetails[idx] &&
                            routeDetails[idx].End &&
                            routeDetails[idx].End.map((row) => (
                              <TableRow>
                                <TableCell style={{ borderBottom: "none" }}>
                                  {row}
                                </TableCell>
                              </TableRow>
                            ))}
                        </TableCell>

                        <TableCell>
                          <TableRow>
                            <TableCell style={{ borderBottom: "none" }}>
                              {routeDetails[idx] && routeDetails[idx].Price}
                            </TableCell>
                          </TableRow>
                        </TableCell>

                        <TableCell>
                          <TableRow>
                            <TableCell style={{ borderBottom: "none" }}>
                              {routeDetails[idx] && <Link href="#">Book</Link>}
                            </TableCell>
                          </TableRow>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : null}
            </Paper>
          </Grid>
        </Grid>

        <Copyright sx={{ pt: 4 }} />
      </Container>
      ;
    </React.Fragment>
  );
};

interface CompProps {}

export default TripPlanner;
