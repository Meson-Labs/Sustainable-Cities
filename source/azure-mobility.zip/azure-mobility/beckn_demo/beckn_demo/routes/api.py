from fastapi import APIRouter
from fastapi.responses import ORJSONResponse

from routes import (
    bg,
    bap_mobility,
    bpp_processing,
    bpp_analytics,
)  # pylint: disable=syntax-error


api_router = APIRouter(default_response_class=ORJSONResponse)
api_router.include_router(bg.router, prefix="/v1/bg", tags=["Beckn Gateway"])
api_router.include_router(
    bap_mobility.router,
    prefix="/v1/bap_mobility",
    tags=["BAP Mobility"],
)
api_router.include_router(
    bpp_processing.router,
    prefix="/v1/bpp_processing",
    tags=["BPP Processing"],
)
api_router.include_router(
    bpp_analytics.router,
    prefix="/v1/bpp_analytics",
    tags=["BPP Analytics"],
)
