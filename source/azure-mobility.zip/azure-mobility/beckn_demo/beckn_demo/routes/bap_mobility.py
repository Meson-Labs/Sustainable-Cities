import logging

from fastapi import APIRouter, Request
from fastapi.responses import ORJSONResponse
from pydantic import BaseModel

from schema.core import Error
from schema.context import Context
from schema.message import MessageForOn_search, MessageForOn_confirm
from utils.wrappers import create_ack_response, create_nack_response
from controllers.bap_mobility import (
    handle_search_providers,
    handle_on_search,
    handle_on_confirm,
    handle_search_by_origin_dest,
)


router = APIRouter(default_response_class=ORJSONResponse)
logger = logging.getLogger(__name__)
route_details = {}


class OrigDestName(BaseModel):
    orig_name: str
    dest_name: str


######################################################################################
## Beckn related endpoints
@router.post("/on_search")
async def on_search(
    context: Context,
    message: MessageForOn_search = None,
    error: Error = None,
):
    try:
        await handle_on_search(context, message)

        ack_response = await create_ack_response(context=context)
        return ack_response
    except Exception as e:
        logger.error(e)
        nack_response = await create_nack_response(context=context)
        return nack_response


@router.post("/on_confirm")
async def on_confirm(
    context: Context,
    message: MessageForOn_confirm = None,
    error: Error = None,
):
    global route_details
    try:
        # await handle_on_confirm(context, message)
        message_body = message.dict()
        route_details = message_body["order"]["fulfillment"]["tags"]["route_details"]

        ack_response = await create_ack_response(context=context)
        return ack_response
    except Exception as e:
        logger.error(e)
        nack_response = await create_nack_response(context=context)
        return nack_response


######################################################################################
## Endpoints for interacting with frontend
@router.post("/search_providers")
async def search_providers(request: Request):
    try:
        await handle_search_providers()
    except Exception as e:
        logger.error(e)

    return {"message": "ok"}


@router.post("/search_by_origin_dest")
async def search_by_origin_dest(orig_dest: OrigDestName):
    try:
        await handle_search_by_origin_dest(orig_dest.orig_name, orig_dest.dest_name)
    except Exception as e:
        logger.error(e)

    return {"message": "ok"}


@router.post("/get_route_details")
async def get_route_details():
    global route_details

    return route_details
