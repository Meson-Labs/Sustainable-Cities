import logging

from fastapi import APIRouter
from fastapi.responses import ORJSONResponse

from schema.context import Context
from schema.message import MessageForSearch, MessageForConfirm
from utils.wrappers import create_ack_response, create_nack_response
from controllers.bpp_analytics import handle_search, handle_confirm


router = APIRouter(default_response_class=ORJSONResponse)
logger = logging.getLogger(__name__)


@router.post("/search")
async def search(
    context: Context,
    message: MessageForSearch,
):
    try:
        await handle_search(context=context, message=message)

        ack_response = await create_ack_response(context=context)
        return ack_response
    except Exception as e:
        logger.error(e)
        nack_response = await create_nack_response(context=context)
        return nack_response


@router.post("/confirm")
async def confirm(
    context: Context,
    message: MessageForConfirm,
):
    try:
        await handle_confirm(context=context, message=message)

        ack_response = await create_ack_response(context=context)
        return ack_response
    except Exception as e:
        logger.error(e)
        nack_response = await create_nack_response(context=context)
        return nack_response
