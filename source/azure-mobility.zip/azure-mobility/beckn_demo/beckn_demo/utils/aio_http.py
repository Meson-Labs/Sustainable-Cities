import aiohttp
import asyncio
from socket import AF_INET

from typing import Optional, Any


SIZE_POOL_AIOHTTP = 100


class AiohttpClient:
    sem: Optional[asyncio.Semaphore] = None
    client: Optional[aiohttp.ClientSession] = None

    @classmethod
    def get_client(cls) -> aiohttp.ClientSession:
        if cls.client is None:
            timeout = aiohttp.ClientTimeout(total=2)
            connector = aiohttp.TCPConnector(
                family=AF_INET, limit_per_host=SIZE_POOL_AIOHTTP
            )
            cls.client = aiohttp.ClientSession(timeout=timeout, connector=connector)

        return cls.client

    @classmethod
    async def close_client(cls) -> None:
        if cls.client:
            await cls.client.close()
            cls.client = None

    @classmethod
    async def post_request(cls, url: str, data: Any) -> Any:
        client = cls.get_client()

        try:
            async with client.post(url, data=data) as response:
                if response.status != 200:
                    return {"ERROR OCCURED" + str(await response.text())}

                json_result = await response.json()
        except Exception as e:
            return {"ERROR": e}

        return json_result
