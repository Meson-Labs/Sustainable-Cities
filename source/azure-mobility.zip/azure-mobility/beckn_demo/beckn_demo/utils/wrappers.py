import os
import orjson

from dotenv import load_dotenv

from schema.enums import AckResponse
from schema.context import Context


async def get_all_nodes():
    load_dotenv()
    registered_nodes = [
        {
            "id": "bpp_processing",
            "long_desc": "BPP for primary processing",
            "uri": f"http://{os.getenv('HOST_URL')}:{os.getenv('PORT')}/v1/bpp_processing",
        },
        {
            "id": "bpp_analytics",
            "long_desc": "BPP for location analytics",
            "uri": f"http://{os.getenv('HOST_URL')}:{os.getenv('PORT')}/v1/bpp_analytics",
        },
        {
            "id": "bg",
            "long_desc": "Beckn Gateway",
            "uri": f"http://{os.getenv('HOST_URL')}:{os.getenv('PORT')}/v1/bg",
        },
        {
            "id": "bap_mobility",
            "long_desc": "BAP for mobility",
            "uri": f"http://{os.getenv('HOST_URL')}:{os.getenv('PORT')}/v1/bap_mobility",
        },
    ]
    for node in registered_nodes:
        yield node


async def get_primary_bg():
    async for node in get_all_nodes():
        if "bg" in node["id"]:
            return node


async def get_bap_details():
    async for node in get_all_nodes():
        if "bap" in node["id"]:
            return node


def create_context(**kwargs):
    file_path = "beckn_demo/json_spec/ack.json"

    context = None
    with open(file_path, "rb", encoding="utf-8") as myfile:
        data = myfile.read()
        context = orjson.loads(data)["context"]
        # context.update(kwargs)
    return context


def get_transaction_id():
    return None


async def create_ack_response(context: Context):
    ack_response = {}
    ack_response["context"] = context.dict()

    ack_response["message"] = {"ack": {"status": AckResponse.ACK}}

    return ack_response


async def create_nack_response(context: Context):
    nack_response = {}
    nack_response["context"] = context.dict()

    nack_response["message"] = {"ack": {"status": AckResponse.NACK}}

    return nack_response
