import os
import uvicorn

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routes.api import api_router
from utils.aio_http import AiohttpClient
from utils.cache import DataCache


origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:80",
    "http://20.51.187.121:7011",
    "*",
]


async def on_start_up() -> None:
    AiohttpClient.get_aiohttp_client()
    DataCache.reset()


async def on_shutdown() -> None:
    await AiohttpClient.close_aiohttp_client()


def setup_app() -> FastAPI:
    load_dotenv()

    fastapi_app = FastAPI(
        title=os.getenv("APP_NAME"),
        version=os.getenv("APP_VERSION"),
        on_start_up=[on_start_up],
        on_shutdown=[on_shutdown],
    )
    fastapi_app.include_router(api_router)

    fastapi_app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    return fastapi_app


app = setup_app()


def main():
    uvicorn.run("app:app", host="0.0.0.0", port=int(os.getenv("PORT")), reload=True)


if __name__ == "__main__":
    main()
