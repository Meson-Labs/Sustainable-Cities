import geopy.distance

import numpy as np
import pandas as pd

from typing import Tuple

from controllers.data import read_data, aggregate_poi


def is_array_like(arr):
    return isinstance(arr, (list, pd.Series, np.ndarray))


def calc_distance(start: Tuple, end: Tuple):
    """
    Calculates Vincenty distance between start and end. Either start or end can be vectors but not both


    Parameters
    ----------
    start : Tuple
        Latitude and longitude can be scalar or vector
    end : Tuple
        Latitude and longitude can be scalar or vector

    """
    if is_array_like(end[0]):
        return [
            geopy.distance.distance(start, end_items).km
            for end_items in zip(end[0], end[1])
        ]
    if is_array_like(start[0]):
        return [
            geopy.distance.distance(start_items, end).km
            for start_items in zip(start[0], start[1])
        ]
    return geopy.distance.distance(start, end).km


def calc_price(orig_coords, dest_coords, mode: str):
    price_per_km = {
        "Walk": 0,
        "Bus": 1,
        "Metro": 2,
        "Auto": 4,
        "Taxi": 14,
    }
    result = round(price_per_km[mode] * calc_distance(orig_coords, dest_coords), 2)
    return result


def get_metro_fare(origin_stop, dest_stop):
    metro_fares = read_data("metro_fares").copy()
    metro_fares = metro_fares.set_index("Unnamed: 0")

    result = float(metro_fares.loc[origin_stop, dest_stop])
    return result


def get_nearest_bus_stop(coords: Tuple) -> dict:
    all_stops = read_data("bus_stops").copy()
    all_stops.columns = [
        "Name",
        "Latitude",
        "Longitude",
    ]
    all_stops["Distance"] = calc_distance(
        coords, (all_stops["Latitude"].values, all_stops["Longitude"].values)
    )
    return all_stops.loc[all_stops["Distance"].idxmin()].to_dict()


def get_nearest_metro_stop(coords: Tuple) -> dict:
    all_stops = read_data("metro_stops").copy()
    all_stops.columns = [
        "StopID",
        "Name",
        "Latitude",
        "Longitude",
        "ZoneID",
        "WheelchairBoarding",
    ]

    all_stops["Distance"] = calc_distance(
        coords, (all_stops["Latitude"].values, all_stops["Longitude"].values)
    )

    all_stops = all_stops[["Name", "Latitude", "Longitude", "Distance"]]
    return all_stops.loc[all_stops["Distance"].idxmin()].to_dict()


def get_nearest_auto_stand(coords: Tuple) -> dict:
    auto_stands = read_data("auto_stands").copy()

    auto_stands["Distance"] = calc_distance(
        coords, (auto_stands["Latitude"].values, auto_stands["Longitude"].values)
    )
    return auto_stands.loc[auto_stands["Distance"].idxmin()].to_dict()


def get_nearest_ferry_stop(coords: Tuple) -> dict:
    all_stops = read_data("ferry_stops").copy()
    all_stops.columns = ["StopID", "Name", "Latitude", "Longitude"]

    all_stops["Distance"] = calc_distance(
        coords, (all_stops["Latitude"].values, all_stops["Longitude"].values)
    )

    all_stops = all_stops[["Name", "Latitude", "Longitude", "Distance"]]
    return all_stops.loc[all_stops["Distance"].idxmin()].to_dict()


def get_nearest_poi(coords: Tuple) -> dict:
    all_poi = read_data("all_poi").copy()
    all_poi.columns = ["Name", "Category", "SubCategory", "Latitude", "Longitude"]

    all_poi["Distance"] = calc_distance(
        coords, (all_poi["Latitude"].values, all_poi["Longitude"].values)
    )

    all_poi = all_poi[["Name", "Latitude", "Longitude", "Distance"]]
    return all_poi.loc[all_poi["Distance"].idxmin()].to_dict()


def get_optimal_route(orig_coords, dest_coords, mode: str):
    if mode == "metro":
        orig_stop = get_nearest_metro_stop(orig_coords)
        dest_stop = get_nearest_metro_stop(dest_coords)
        result = (orig_stop, dest_stop)
    elif mode == "ferry":
        orig_stop = get_nearest_ferry_stop(orig_coords)
        dest_stop = get_nearest_ferry_stop(dest_coords)
        result = (orig_stop, dest_stop)
    elif mode == "bus":
        orig_stop = get_nearest_bus_stop(orig_coords)
        dest_stop = get_nearest_bus_stop(dest_coords)
        result = (orig_stop, dest_stop)
    elif mode == "auto":
        orig_stop = get_nearest_auto_stand(orig_coords)
        dest_stop = get_nearest_auto_stand(dest_coords)
        result = (orig_stop, dest_stop)

    return result


def get_poi_routes(start_poi_name: str, end_poi_name: str, mode: str = "metro"):
    route_details = []

    all_poi = aggregate_poi()
    start_poi_idx = all_poi.loc[all_poi["Name"] == start_poi_name].index
    end_poi_idx = all_poi.loc[all_poi["Name"] == end_poi_name].index

    orig_coords = (
        all_poi.loc[start_poi_idx, "Latitude"].values[0],
        all_poi.loc[start_poi_idx, "Longitude"].values[0],
    )
    dest_coords = (
        all_poi.loc[end_poi_idx, "Latitude"].values[0],
        all_poi.loc[end_poi_idx, "Longitude"].values[0],
    )

    metro_stops = get_optimal_route(orig_coords, dest_coords, mode="metro")
    if metro_stops[0]["Name"] == metro_stops[1]["Name"]:
        modes = ["Auto"]
        route_start = [start_poi_name]
        route_end = [end_poi_name]
        price = calc_price(orig_coords, dest_coords, mode="Auto")
    else:
        modes = ["Auto", "Metro", "Auto"]
        route_start = [
            start_poi_name,
            metro_stops[0]["Name"],
            metro_stops[1]["Name"],
        ]
        route_end = [
            metro_stops[0]["Name"],
            metro_stops[1]["Name"],
            end_poi_name,
        ]
        price = (
            calc_price(
                orig_coords,
                (metro_stops[0]["Latitude"], metro_stops[0]["Longitude"]),
                mode="Auto",
            )
            + get_metro_fare(metro_stops[0]["Name"], metro_stops[1]["Name"])
            + calc_price(
                (metro_stops[1]["Latitude"], metro_stops[1]["Longitude"]),
                dest_coords,
                mode="Auto",
            )
        )
    route_details.append(
        {"Mode": modes, "Start": route_start, "End": route_end, "Price": round(price, 2)}
    )

    bus_stops = get_optimal_route(orig_coords, dest_coords, mode="bus")
    if bus_stops[0]["Name"] == bus_stops[1]["Name"]:
        modes = ["Walk"]
        route_start = [start_poi_name]
        route_end = [end_poi_name]
        price = calc_price(orig_coords, dest_coords, mode="Walk")
    else:
        modes = ["Walk", "Bus", "Walk"]
        route_start = [
            start_poi_name,
            bus_stops[0]["Name"],
            bus_stops[1]["Name"],
        ]
        route_end = [
            bus_stops[0]["Name"],
            bus_stops[1]["Name"],
            end_poi_name,
        ]
        price = calc_price(
            (bus_stops[0]["Latitude"], bus_stops[0]["Longitude"]),
            (bus_stops[1]["Latitude"], bus_stops[1]["Longitude"]),
            mode="Bus",
        )
    route_details.append(
        {"Mode": modes, "Start": route_start, "End": route_end, "Price": price}
    )

    modes = ["Taxi"]
    route_start = [start_poi_name]
    route_end = [end_poi_name]
    price = calc_price(orig_coords, dest_coords, mode="Taxi")
    route_details.append(
        {"Mode": modes, "Start": route_start, "End": route_end, "Price": price}
    )

    return route_details


def convert_poi_name_to_coords(start_poi_name: str, end_poi_name: str):
    all_poi = aggregate_poi()
    start_poi_idx = all_poi.loc[all_poi["Name"] == start_poi_name].index
    end_poi_idx = all_poi.loc[all_poi["Name"] == end_poi_name].index

    orig_coords = (
        all_poi.loc[start_poi_idx, "Latitude"].values[0],
        all_poi.loc[start_poi_idx, "Longitude"].values[0],
    )
    dest_coords = (
        all_poi.loc[end_poi_idx, "Latitude"].values[0],
        all_poi.loc[end_poi_idx, "Longitude"].values[0],
    )

    return (orig_coords, dest_coords)


def convert_coords_to_poi_name(start_coords, end_coords):
    all_poi = aggregate_poi()

    start_poi_idx = all_poi.loc[
        (all_poi["Latitude"] == start_coords[0])
        & (all_poi["Longitude"] == start_coords[1])
    ].index
    end_poi_idx = all_poi.loc[
        (all_poi["Latitude"] == end_coords[0]) & (all_poi["Longitude"] == end_coords[1])
    ].index

    start_poi_name = all_poi.loc[start_poi_idx, "Name"].values[0]
    end_poi_name = all_poi.loc[end_poi_idx, "Name"].values[0]

    return (start_poi_name, end_poi_name)
