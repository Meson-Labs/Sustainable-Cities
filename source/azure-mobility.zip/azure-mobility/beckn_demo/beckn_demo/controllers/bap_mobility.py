import logging
import orjson

from pydantic import ValidationError

from schema.core import Order
from schema.context import Context
from schema.message import (
    MessageForSearch,
    MessageForOn_search,
    MessageForConfirm,
    MessageForOn_confirm,
    MessageForSelect,
)

from utils.core import convert_coords_to_str
from utils.wrappers import get_primary_bg, get_bap_details
from utils.aio_http import AiohttpClient

from controllers.geo import convert_poi_name_to_coords


logger = logging.getLogger(__name__)

# Use this to store details of BPPs with which to transact later
selected_bpp = {}


async def create_search_context():
    bap_details = await get_bap_details()
    search_context = {
        "domain": "mobility",
        "country": "IND",
        "city": "std:080",
        "action": "search",
        "core_version": "0.9.1",
        "bap_id": bap_details["id"],
        "bap_uri": bap_details["uri"],
        "bpp_id": "",
        "bpp_uri": "",
        "transaction_id": "0001",
        "message_id": "0001",
        "key": "",
        "timestamp": "",
    }
    return search_context


async def create_search_provider_message():
    search_message = MessageForSearch(
        intent={
            "provider": {
                "categories": [
                    {
                        "id": "mobility",
                        "descriptor": {
                            "name": "mobility",
                        },
                    }
                ]
            }
        }
    )
    return search_message.dict()


async def handle_search_providers():
    search_body = {
        "context": await create_search_context(),
        "message": await create_search_provider_message(),
    }

    bg_node = await get_primary_bg()
    bg_uri = bg_node["uri"]

    response = await AiohttpClient.post_request(
        url=f"{bg_uri}/search",
        data=orjson.dumps(search_body),
    )
    return response


async def handle_select():
    context = await create_search_context()
    context["action"] = "select"

    if "bpp_analytics" not in selected_bpp:
        await handle_search_providers()

    if "bpp_analytics" in selected_bpp:
        bpp_uri = selected_bpp["bpp_analytics"]["uri"]

        context["bpp_id"] = "bpp_analytics"
        context["bpp_uri"] = bpp_uri
        catalog = selected_bpp["bpp_analytics"]["catalog"]

        try:
            message = MessageForSelect(
                order_items=[
                    {
                        "id": catalog["bpp_offers"][0]["item_ids"][0],
                        "quantity": {
                            "count": 1,
                            "measure": {"unit": "request"},
                        },
                    }
                ]
            )
        except ValidationError as e:
            logger.error(e)
        select_body = {
            "context": context,
            "message": message.dict(),
        }

        response = await AiohttpClient.post_request(
            url=f"{bpp_uri}/select",
            data=orjson.dumps(select_body),
        )
        return response


async def handle_search_by_origin_dest(orig_name, dest_name):
    context = await create_search_context()
    context["action"] = "search"

    orig_coords, dest_coords = convert_poi_name_to_coords(orig_name, dest_name)

    if "bpp_analytics" not in selected_bpp:
        await handle_search_providers()

    if "bpp_analytics" in selected_bpp:
        bpp_uri = selected_bpp["bpp_analytics"]["uri"]

        context["bpp_id"] = "bpp_analytics"
        context["bpp_uri"] = bpp_uri

        try:
            message = MessageForConfirm(
                order={
                    "fulfillment": {
                        "start": {
                            "location": {
                                "gps": convert_coords_to_str(orig_coords),
                            }
                        },
                        "end": {
                            "location": {
                                "gps": convert_coords_to_str(dest_coords),
                            }
                        },
                    }
                },
            )
        except ValidationError as e:
            logger.error(f"Validation error: {e}")
        search_body = {
            "context": context,
            "message": message.dict(),
        }

        response = await AiohttpClient.post_request(
            url=f"{bpp_uri}/confirm",
            data=orjson.dumps(search_body),
        )
        return response


async def handle_on_search(
    context: Context,
    message: MessageForOn_search,
):
    # For BPPs that have responded, save catalog details locally
    if "bpp_id" in context.dict() and context.dict()["bpp_id"] != "":
        selected_bpp[context.dict()["bpp_id"]] = {
            "uri": context.dict()["bpp_uri"],
            "catalog": message.dict()["catalog"],
        }


async def handle_on_confirm(
    context: Context,
    message: MessageForOn_confirm,
):
    message_body = message.dict()
    route_details = message_body["order"]["fulfillment"]["tags"]["route_details"]
