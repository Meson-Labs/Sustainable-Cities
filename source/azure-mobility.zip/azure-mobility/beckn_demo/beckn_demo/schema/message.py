from typing import List, Optional
from pydantic import BaseModel

from schema.core import Intent, Catalog, ScalarQuantity, Order


class OrderItemQuantity(BaseModel):
    id: str = None
    quantity: ScalarQuantity


class MessageForSearch(BaseModel):
    intent: Intent = None


class MessageForConfirm(BaseModel):
    order: Order = None


class MessageForOn_search(BaseModel):
    catalog: Optional[Catalog] = None


class MessageForSelect(BaseModel):
    order_items: List[OrderItemQuantity] = None
    order_addons: List[str] = None
    order_offers: List[str] = None


class MessageForOn_confirm(BaseModel):
    order: Order = None
