from pydantic import BaseModel


class Context(BaseModel):
    domain: str = None
    country: str = None
    city: str = None
    action: str = None
    core_version: str = None
    bap_id: str = None
    bap_uri: str = None
    bpp_id: str = None
    bpp_uri: str = None
    transaction_id: str = None
    message_id: str = None
    timestamp: str = None
    key: str = None
    ttl: str = None


class ContextForSearch(BaseModel):
    domain: str = None
    country: str = None
    city: str = None
    action: str = None
    core_version: str = None
    bap_id: str = None
    bap_uri: str = None
    bpp_id: str = None
    bpp_uri: str = None
    transaction_id: str = None
    message_id: str = None
    timestamp: str = None
    key: str = None
    ttl: str = None
