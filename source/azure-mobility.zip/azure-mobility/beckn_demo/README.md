## Installation and usage

- Create python virtual environment

  ```bash
  python3 -m venv .venv
  ```

- Upgrade pip and load requirements

  ```bash
  source .venv/bin/activate
  pip3 install --upgrade pip
  pip3 install -r requirements.txt
  ```

- To start in native mode (linux)

  ```bash
  cd beckn_demo
  ../scripts/run-app.sh
  ```

- To start in docker container
  ```bash
  docker-compose up -d
  ```
